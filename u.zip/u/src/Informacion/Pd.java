/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Informacion;

import java.util.Date;

/**
 *
 * @author Carlos Sanabria
 */
public class Pd {

    public Pd(int idpedido, Long cedulaCliente, Long cedulaEmpleado, Date fechapedido, int idproducto, String producto, String categria, Long valortotal) {
        this.idpedido = idpedido;
        this.cedulaCliente = cedulaCliente;
        this.cedulaEmpleado = cedulaEmpleado;
        this.fechapedido = fechapedido;
        this.idproducto = idproducto;
        this.producto = producto;
        this.categria = categria;
        this.valortotal = valortotal;
    }

    public int getIdpedido() {
        return idpedido;
    }

    public void setIdpedido(int idpedido) {
        this.idpedido = idpedido;
    }

    public Long getCedulaCliente() {
        return cedulaCliente;
    }

    public void setCedulaCliente(Long cedulaCliente) {
        this.cedulaCliente = cedulaCliente;
    }

    public Long getCedulaEmpleado() {
        return cedulaEmpleado;
    }

    public void setCedulaEmpleado(Long cedulaEmpleado) {
        this.cedulaEmpleado = cedulaEmpleado;
    }

    public Date getFechapedido() {
        return fechapedido;
    }

    public void setFechapedido(Date fechapedido) {
        this.fechapedido = fechapedido;
    }

    public int getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(int idproducto) {
        this.idproducto = idproducto;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getCategria() {
        return categria;
    }

    public void setCategria(String categria) {
        this.categria = categria;
    }

    public Long getValortotal() {
        return valortotal;
    }

    public void setValortotal(Long valortotal) {
        this.valortotal = valortotal;
    }

  
    private int idpedido;
    private Long cedulaCliente;
    private Long cedulaEmpleado;
    private java.util.Date fechapedido;
    private int idproducto;
    private String producto;
    private String categria;
    private Long valortotal;

    
}
